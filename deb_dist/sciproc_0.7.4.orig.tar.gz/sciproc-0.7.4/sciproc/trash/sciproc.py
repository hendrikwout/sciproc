#def sciproc(mode = "scisel",indata, coords):
#
#    for icoords in coords:
#        # select last mode
#        thismode = min(icoords,len(mode))
#
#        if (mode == "scisel"):
#            
#            
#            indata[ ,  , 
#        
#
#    if 
#
#    get dim indata
#    
#    for idim in dim:
#        if (coors[idim] == None):
#            coors[idim] = range(startco,endco,codelta)
#    for idim in dim:
#        if (outcoors[idim] == None):
#            outcoors[idim] = range(outstartco,outendco,outcodelta)
#        if (outcoors[idim] == None):
#            outcoors[idim] = coors[idim]
#### second


# matout = len(coords[0]*coords[1]*...*coords[k-1])
# for i in range(coords[0]*coords[1]*coords[2]*...*coords[k-1]):
#     for j in range(coords[l+1]*...coords[n]):
#         idxs = range(coords[k]*coords[k+1]*...*coords[l])*coords[l+1]*...coords[n]+i+j
#             tempmatout = f(matin[idxs])
#            matout[i+j:i+j+len(tempmatout)] = tempmatout



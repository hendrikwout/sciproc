from distutils.core import setup

setup(
    name='sciproc',
    version='0.2.4',
    author='H. Wouters',
    author_email='hendrikwout@gmail.com',
    packages=['sciproc'],
    url='http://www.nowebsite.com',
    license='LICENSE.txt',
    description='Process scientific data.',
    long_description=open('README.txt').read(),
)


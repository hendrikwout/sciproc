#def sciproc(mode = "scisel",indata, coords):
#
#    for icoords in coords:
#        # select last mode
#        thismode = min(icoords,len(mode))
#
#        if (mode == "scisel"):
#            
#            
#            indata[ ,  , 
#        
#
#    if 
#
#    get dim indata
#    
#    for idim in dim:
#        if (coors[idim] == None):
#            coors[idim] = range(startco,endco,codelta)
#    for idim in dim:
#        if (outcoors[idim] == None):
#            outcoors[idim] = range(outstartco,outendco,outcodelta)
#        if (outcoors[idim] == None):
#            outcoors[idim] = coors[idim]



